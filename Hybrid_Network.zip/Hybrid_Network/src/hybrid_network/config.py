"""
Configuration management using type-safe dataclasses and YAML loading.
Strictly replaces argparse across all benchmark entry points and experiments.
"""

import os
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]


@dataclass
class DANNSimulationConfig:
    """Configuration for DANN & HDANN simulation benchmark (Models 1, 2, 3, 4)."""
    output_dir: str = "artifacts/metrics/dann_simulation"
    model_types: List[int] = field(default_factory=lambda: [1, 2, 3, 4])
    scenarios: List[int] = field(default_factory=lambda: [1, 2])
    seeds: List[int] = field(default_factory=lambda: [702, 968, 983, 1428, 2995])
    num_layer_list: List[int] = field(default_factory=lambda: [1, 3, 5, 7, 9])
    unit_size_list: List[int] = field(default_factory=lambda: [4, 16, 64, 256, 1024])
    activation_list: List[str] = field(default_factory=lambda: ["ReLU", "sigmoid", "tanh"])
    orders: List[int] = field(default_factory=lambda: [2, 3, 4, 5])
    dnn_num_layer_list: List[int] = field(default_factory=lambda: [2, 4, 6, 8, 10, 12, 14, 16, 18])
    dnn_unit_size_list: List[int] = field(default_factory=lambda: [8, 32, 128, 512, 2048])
    dnn_activation_list: List[str] = field(default_factory=lambda: ["ReLU", "sigmoid", "tanh"])
    epochs: int = 5000
    lr: float = 1e-4
    batch_size: int = 512
    steps_per_execution: int = 4
    jit_compile: bool = False
    patience: int = 10
    min_delta: float = 1e-3
    gpu_id: Optional[str] = "0"
    strict_determinism: bool = False


@dataclass
class DANNRealDataConfig:
    """Configuration for DANN & HDANN California Housing 5-fold cross-validation."""
    data_path: str = "data/raw/housing.csv"
    output_dir: str = "artifacts/metrics/dann_real_data"
    splits: List[str] = field(default_factory=lambda: ["A", "B", "C", "D", "E"])
    num_layer_list: List[int] = field(default_factory=lambda: [1, 3, 5, 7, 9])
    unit_size_list: List[int] = field(default_factory=lambda: [4, 16, 64, 256, 1024])
    activation_list: List[str] = field(default_factory=lambda: ["ReLU", "sigmoid", "tanh"])
    orders: List[int] = field(default_factory=lambda: [2, 3, 4, 5])
    dnn_num_layer_list: List[int] = field(default_factory=lambda: [2, 4, 6, 8, 10, 12, 14, 16, 18])
    dnn_unit_size_list: List[int] = field(default_factory=lambda: [8, 32, 128, 512, 2048])
    dnn_activation_list: List[str] = field(default_factory=lambda: ["ReLU", "sigmoid", "tanh"])
    epochs: int = 5000
    lr: float = 1e-4
    batch_size: int = 512
    steps_per_execution: int = 4
    jit_compile: bool = False
    patience: int = 10
    min_delta: float = 1e-3
    gpu_id: Optional[str] = "0"
    strict_determinism: bool = False


@dataclass
class KANSimulationConfig:
    """Configuration for KAN simulation benchmark (Models 1, 2, 3, 4)."""
    output_dir: str = "artifacts/metrics/kan_simulation"
    model_types: List[int] = field(default_factory=lambda: [1, 2, 3, 4])
    scenarios: List[int] = field(default_factory=lambda: [1, 2])
    seeds: List[int] = field(default_factory=lambda: [702, 968, 983, 1428, 2995])
    sweep_mode: str = "sweep"
    custom_widths: Optional[str] = None
    grids: List[int] = field(default_factory=lambda: [3, 5])
    ks: List[int] = field(default_factory=lambda: [2, 3])
    epochs: int = 5000
    opt: str = "Adam"
    lr: float = 1e-4
    patience: int = 10
    min_delta: float = 1e-3
    monitor: str = "loss"
    restore_best_weights: bool = True
    device: str = "0"
    strict_determinism: bool = False


@dataclass
class KANRealDataConfig:
    """Configuration for KAN California Housing 5-fold cross-validation."""
    data_path: str = "data/raw/housing.csv"
    output_dir: str = "artifacts/metrics/kan_real_data"
    splits: List[str] = field(default_factory=lambda: ["A", "B", "C", "D", "E"])
    sweep_mode: str = "sweep"
    custom_widths: Optional[str] = None
    grids: List[int] = field(default_factory=lambda: [3, 5])
    ks: List[int] = field(default_factory=lambda: [2, 3])
    epochs: int = 5000
    opt: str = "Adam"
    lr: Optional[float] = None
    patience: int = 10
    min_delta: float = 1e-3
    monitor: str = "loss"
    restore_best_weights: bool = True
    device: str = "0"
    strict_determinism: bool = False


T = TypeVar("T")


def load_config(config_cls: Type[T], default_yaml_path: Optional[str] = None) -> T:
    """
    Load configuration from YAML file and instantiate the target dataclass.
    Prioritizes HYBRID_CONFIG environment variable if set; otherwise uses default_yaml_path.
    """
    config_path = os.environ.get("HYBRID_CONFIG") or default_yaml_path
    
    if config_path is None:
        return config_cls()

    # Resolve relative paths with respect to PROJECT_ROOT
    resolved_path = Path(config_path)
    if not resolved_path.is_absolute():
        candidate_paths = [
            PROJECT_ROOT / config_path,
            Path.cwd() / config_path,
            resolved_path
        ]
        for cp in candidate_paths:
            if cp.exists():
                resolved_path = cp
                break

    if not resolved_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(resolved_path, "r", encoding="utf-8") as f:
        data: Dict[str, Any] = yaml.safe_load(f) or {}

    # Filter keys matching dataclass fields
    valid_field_names = {f.name for f in fields(config_cls)}
    filtered_data = {k: v for k, v in data.items() if k in valid_field_names}

    return config_cls(**filtered_data)
