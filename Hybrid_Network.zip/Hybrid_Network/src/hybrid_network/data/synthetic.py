"""
Unified Synthetic Simulation Data Generator for Models 1, 2, 3 (d=6) and Model 4 (d=8).
Conforms strictly to benchmark specifications for Scenarios 1 and 2.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Tuple
import numpy as np


@dataclass(frozen=True)
class DataSplit:
    """Standardized dataset partition container used across all models."""
    train_x: np.ndarray       # shape (N_train, d)
    train_y_norm: np.ndarray  # shape (N_train,), normalized with train_y stats
    val_x: np.ndarray         # shape (N_val, d)
    val_y_norm: np.ndarray    # shape (N_val,), normalized with train_y stats
    test_x: np.ndarray        # shape (N_test, d)
    test_y_norm: np.ndarray   # shape (N_test,), normalized with train_y stats
    y_mean: float
    y_std: float
    input_dim: int
    meta: Dict[str, Any] = field(default_factory=dict)


def gen_sim_data(
    n_sample: int,
    mean: float = 0.0,
    sigma: float = 0.1,
    model_type: int = 1
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate synthetic input features and target values for benchmark simulation models.
    - Model 1, 2, 3: 6 features
    - Model 4: 8 features (quadrant indicator, non-linear interaction, trigonometric)
    """
    num_features = 8 if model_type == 4 else 6
    data_x = np.random.uniform(0.0, 1.0, n_sample * num_features).reshape(-1, num_features)
    noise = np.random.normal(mean, sigma, n_sample)

    if model_type == 1:
        data_y = np.exp(
            (data_x[:, 0] ** 3) + (data_x[:, 1] ** 3) + (data_x[:, 2] ** 3) -
            (data_x[:, 3] ** 3) - (data_x[:, 4] ** 3) - (data_x[:, 5] ** 3)
        ) + noise
    elif model_type == 2:
        data_y = (
            1.0 + data_x[:, 0] + 2.0 * (data_x[:, 1] ** 2) + 3.0 * (data_x[:, 2] ** 3) -
            np.exp(data_x[:, 3]) - np.log(data_x[:, 4] + 1.0) - np.abs(data_x[:, 5] - 0.5)
        ) ** 2 + noise
    elif model_type == 3:
        data_y = (
            np.sin(data_x[:, 0] * data_x[:, 1] * data_x[:, 2]) +
            data_x[:, 3] / (0.2 + ((data_x[:, 4] * data_x[:, 5]) ** 2))
        ) + noise
    elif model_type == 4:
        cond = (data_x[:, 0] - 0.5) * (data_x[:, 1] - 0.5)
        indicator = np.where(cond >= 0.0, 1.0, 0.0)
        data_y = (
            5.0 * indicator -
            3.0 * np.abs(data_x[:, 2] * data_x[:, 3] - 0.25) +
            2.0 * np.cos(np.pi * data_x[:, 5] * data_x[:, 6])
        ) + noise
    else:
        raise ValueError(f"Unknown model_type: {model_type}. Expected 1, 2, 3, or 4.")

    return data_x, data_y


def prepare_synthetic_split(
    model_type: int,
    scenario: int,
    seed: int,
    mean: float = 0.0,
    sigma: float = 0.1
) -> DataSplit:
    """
    Generate and partition synthetic data for a given (model_type, scenario, seed).
    - Scenario 1: N = 2000, Train = 1000, Val = 500, Test = 500
    - Scenario 2: N = 3000, Train = 2000, Val = 500, Test = 500
    """
    if scenario == 1:
        n_sample = 2000
        train_size = 1000
    elif scenario == 2:
        n_sample = 3000
        train_size = 2000
    else:
        raise ValueError(f"Unsupported scenario: {scenario}. Expected 1 or 2.")

    data_x, data_y = gen_sim_data(n_sample=n_sample, mean=mean, sigma=sigma, model_type=model_type)
    y_mean = float(np.mean(data_y[:train_size]))
    y_std = float(np.std(data_y[:train_size]))
    if y_std < 1e-7:
        y_std = 1.0

    train_x = data_x[:train_size, :].copy()
    train_y_norm = ((data_y[:train_size] - y_mean) / y_std).copy()

    val_x = data_x[train_size : train_size + 500, :].copy()
    val_y_norm = ((data_y[train_size : train_size + 500] - y_mean) / y_std).copy()

    test_x = data_x[train_size + 500 : train_size + 1000, :].copy()
    test_y_norm = ((data_y[train_size + 500 : train_size + 1000] - y_mean) / y_std).copy()

    return DataSplit(
        train_x=train_x,
        train_y_norm=train_y_norm,
        val_x=val_x,
        val_y_norm=val_y_norm,
        test_x=test_x,
        test_y_norm=test_y_norm,
        y_mean=y_mean,
        y_std=y_std,
        input_dim=data_x.shape[1],
        meta={
            "Model_Type": int(model_type),
            "Scenario": int(scenario),
            "Seed": int(seed),
        }
    )
