"""
Data pipelines and dataset preprocessing for synthetic and real-world benchmarks.
Pure NumPy/Pandas implementations, completely independent of TensorFlow and PyTorch.
"""

from .synthetic import DataSplit, gen_sim_data, prepare_synthetic_split
from .housing import CV_SPLIT_DEFINITIONS, load_and_split_housing_data, prepare_housing_split

__all__ = [
    "DataSplit",
    "gen_sim_data",
    "prepare_synthetic_split",
    "CV_SPLIT_DEFINITIONS",
    "load_and_split_housing_data",
    "prepare_housing_split",
]
