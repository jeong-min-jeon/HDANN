"""
California Housing Real Dataset Pipeline with 5-Fold Cross-Validation.
Deterministic partitioning (seed=2024) across Subsets A, B, C, D, E.
Features are min-max scaled into [0, 1] using training-partition statistics.
Targets are standardized (z-score) using training-partition mean and std.
"""

import os
from pathlib import Path
from typing import Dict, Tuple
import numpy as np
import pandas as pd

from .synthetic import DataSplit

CV_SPLIT_DEFINITIONS = {
    "A": {"train": ["A", "B", "C"], "val": "D", "test": "E"},
    "B": {"train": ["B", "C", "D"], "val": "E", "test": "A"},
    "C": {"train": ["C", "D", "E"], "val": "A", "test": "B"},
    "D": {"train": ["D", "E", "A"], "val": "B", "test": "C"},
    "E": {"train": ["E", "A", "B"], "val": "C", "test": "D"},
}


def load_and_split_housing_data(data_path: str, seed: int = 2024) -> Dict[str, pd.DataFrame]:
    """
    Load California Housing dataset and perform deterministic 5-way partitioning.
    Preserves exact partitioning logic and random seed (2024) from benchmark specifications.
    """
    path = Path(data_path)
    if not path.exists():
        # Check relative fallback
        alt_paths = [
            Path(__file__).resolve().parents[3] / "data/raw/housing.csv",
            Path(__file__).resolve().parents[3] / "housing.csv",
            Path.cwd() / data_path,
        ]
        for ap in alt_paths:
            if ap.exists():
                path = ap
                break

    if not path.exists():
        raise FileNotFoundError(f"Housing dataset not found at: {data_path}")

    df = pd.read_csv(path).iloc[:, 1:]
    # Drop rows with NaN
    df = df.iloc[np.where(df.isna().apply(sum, 1) == 0)[0], :]

    np.random.seed(seed)
    n_obs = df.shape[0]
    index = np.linspace(0, n_obs - 1, n_obs).astype(int)
    np.random.shuffle(index)

    subsets = {
        "A": df.iloc[index[: np.round(n_obs * 0.2).astype(int)], :],
        "B": df.iloc[index[np.round(n_obs * 0.2).astype(int) : np.round(n_obs * 0.4).astype(int)], :],
        "C": df.iloc[index[np.round(n_obs * 0.4).astype(int) : np.round(n_obs * 0.6).astype(int)], :],
        "D": df.iloc[index[np.round(n_obs * 0.6).astype(int) : np.round(n_obs * 0.8).astype(int)], :],
        "E": df.iloc[index[np.round(n_obs * 0.8).astype(int) :], :],
    }
    return subsets


def prepare_housing_split(
    data_path: str,
    split: str,
    seed: int = 2024
) -> DataSplit:
    """
    Construct normalized train, validation, and test arrays for the specified split (A, B, C, D, E).
    Feature min-max scaling and target standardization are strictly fit on the training fold.
    """
    split = split.upper().strip()
    if split not in CV_SPLIT_DEFINITIONS:
        raise ValueError(f"Unknown split '{split}'. Available splits: {list(CV_SPLIT_DEFINITIONS.keys())}")

    subsets = load_and_split_housing_data(data_path=data_path, seed=seed)
    split_def = CV_SPLIT_DEFINITIONS[split]
    train_keys = split_def["train"]
    val_key = split_def["val"]
    test_key = split_def["test"]

    train_df = pd.concat([subsets[k] for k in train_keys])
    val_df = subsets[val_key]
    test_df = subsets[test_key]

    num_features = train_df.shape[1] - 1  # 8 features for California Housing

    train_x_raw = train_df.iloc[:, :num_features].values
    val_x_raw = val_df.iloc[:, :num_features].values
    test_x_raw = test_df.iloc[:, :num_features].values

    train_y_raw = train_df.iloc[:, -1].values
    val_y_raw = val_df.iloc[:, -1].values
    test_y_raw = test_df.iloc[:, -1].values

    # Feature min-max normalization to [0, 1] strictly based on training partition
    x_min = np.min(train_x_raw, axis=0)
    x_max = np.max(train_x_raw, axis=0)
    x_range = np.where(x_max - x_min == 0, 1.0, x_max - x_min)

    train_x = (train_x_raw - x_min) / x_range
    val_x = (val_x_raw - x_min) / x_range
    test_x = (test_x_raw - x_min) / x_range

    # Target standardization based on training partition
    y_mean = float(np.mean(train_y_raw))
    y_std = float(np.std(train_y_raw))
    if y_std < 1e-7:
        y_std = 1.0

    train_y_norm = (train_y_raw - y_mean) / y_std
    val_y_norm = (val_y_raw - y_mean) / y_std
    test_y_norm = (test_y_raw - y_mean) / y_std

    return DataSplit(
        train_x=train_x,
        train_y_norm=train_y_norm,
        val_x=val_x,
        val_y_norm=val_y_norm,
        test_x=test_x,
        test_y_norm=test_y_norm,
        y_mean=y_mean,
        y_std=y_std,
        input_dim=num_features,
        meta={
            "Split": split,
            "Dataset": "California_Housing",
            "Train_Splits": train_keys,
            "Val_Split": val_key,
            "Test_Split": test_key,
        }
    )
