"""
KAN Fitting with EarlyStopping and Metric Evaluation.
Conforms strictly to pykan 0.1.4 and 0.2.x API.
PyTorch / pykan environment only.
"""

import copy
import gc
import time
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import torch

from ..data.synthetic import DataSplit
from ..utils.seed import set_kan_seed
from .models import build_kan_model
from .patches import ensure_kan_device


def fit_kan_with_early_stopping(
    model: torch.nn.Module,
    dataset: Dict[str, torch.Tensor],
    opt: str = "Adam",
    steps: int = 5000,
    lr: float = 1e-4,
    patience: int = 10,
    min_delta: float = 1e-3,
    monitor: str = "loss",
    restore_best_weights: bool = True,
    lamb: float = 0.0,
    update_grid: bool = True,
    grid_update_num: int = 10,
    stop_grid_update_step: int = 50,
    start_grid_update_step: int = -1,
) -> Tuple[Dict[str, List[float]], bool, int]:
    """
    Train a KAN model with exact parity to tf.keras EarlyStopping(monitor='loss', patience=10, min_delta=1e-3).
    Returns (results_dict, stopped_early, epochs_trained).
    """
    train_x, train_y = dataset["train_input"], dataset["train_label"]
    test_x, test_y = dataset["test_input"], dataset["test_label"]

    ensure_kan_device(model, train_x.device)

    old_symbolic_enabled = getattr(model, "symbolic_enabled", False)
    if hasattr(model, "disable_symbolic_in_fit"):
        try:
            _, old_symbolic_enabled = model.disable_symbolic_in_fit(lamb)
        except Exception:
            model.symbolic_enabled = False
    else:
        model.symbolic_enabled = False

    loss_fn = lambda x, y: torch.mean((x - y) ** 2)

    if hasattr(model, "get_params"):
        trainable_params = model.get_params()
    else:
        trainable_params = [p for p in model.parameters() if p.requires_grad]

    if opt == "Adam":
        optimizer = torch.optim.Adam(trainable_params, lr=lr)
    elif opt == "LBFGS":
        try:
            from kan.LBFGS import LBFGS
        except ImportError:
            from torch.optim import LBFGS
        optimizer = LBFGS(
            trainable_params,
            lr=lr,
            history_size=10,
            line_search_fn="strong_wolfe",
            tolerance_grad=1e-32,
            tolerance_change=1e-32,
            tolerance_ys=1e-32,
        )
    else:
        raise ValueError(f"Unknown optimizer: {opt}. Expected 'Adam' or 'LBFGS'.")

    results = {"train_loss": [], "test_loss": [], "reg": []}
    grid_update_freq = max(1, int(stop_grid_update_step / max(1, grid_update_num)))

    best_score = float("inf")
    best_weights = copy.deepcopy(model.state_dict()) if restore_best_weights else None
    no_improve_count = 0
    stopped_early = False

    for step in range(steps):
        # Spline grid update
        if (
            step % grid_update_freq == 0
            and step < stop_grid_update_step
            and update_grid
            and step >= start_grid_update_step
        ):
            if hasattr(model, "update_grid_from_samples"):
                model.update_grid_from_samples(train_x)
            elif hasattr(model, "update_grid"):
                model.update_grid(train_x)

        current_train_loss = [torch.tensor(0.0, device=train_x.device)]

        if opt == "LBFGS":
            def closure():
                optimizer.zero_grad()
                pred = model.forward(train_x)
                l = loss_fn(pred, train_y)
                current_train_loss[0] = l
                l.backward()
                return l
            optimizer.step(closure)
        else:
            optimizer.zero_grad()
            pred = model.forward(train_x)
            l = loss_fn(pred, train_y)
            current_train_loss[0] = l
            l.backward()
            optimizer.step()

        with torch.no_grad():
            test_pred = model.forward(test_x)
            test_l = loss_fn(test_pred, test_y)

        train_rmse = float(torch.sqrt(current_train_loss[0]).detach().cpu().item())
        test_rmse = float(torch.sqrt(test_l).detach().cpu().item())

        results["train_loss"].append(train_rmse)
        results["test_loss"].append(test_rmse)
        results["reg"].append(0.0)

        # Early Stopping check
        if patience is not None and patience > 0:
            target_metric = train_rmse if monitor == "loss" else test_rmse
            if target_metric < best_score - min_delta:
                best_score = target_metric
                no_improve_count = 0
                if restore_best_weights:
                    best_weights = copy.deepcopy(model.state_dict())
            else:
                no_improve_count += 1
                if no_improve_count >= patience:
                    stopped_early = True
                    break

    if restore_best_weights and best_weights is not None:
        model.load_state_dict(best_weights)
        ensure_kan_device(model, train_x.device)

    model.symbolic_enabled = old_symbolic_enabled
    return results, stopped_early, len(results["train_loss"])


def train_and_evaluate_kan(
    width: List[int],
    grid: int,
    k: int,
    data_split: DataSplit,
    seed: int,
    epochs: int = 5000,
    opt: str = "Adam",
    lr: Optional[float] = None,
    patience: int = 10,
    min_delta: float = 1e-3,
    monitor: str = "loss",
    restore_best_weights: bool = True,
    device_str: str = "0",
    strict_determinism: bool = False,
) -> Tuple[Any, Dict[str, Any]]:
    """
    Train a single KAN model on a DataSplit and return (model, metrics_dict).
    Evaluation metrics (Min Loss, Val Error, Test Error) are unnormalized using (* y_std^2).
    """
    set_kan_seed(seed=seed, strict_determinism=strict_determinism)

    # Resolve target device
    if str(device_str).strip().lower() != "cpu" and torch.cuda.is_available():
        gpu_idx = int(device_str) if str(device_str).isdigit() else 0
        device = torch.device(f"cuda:{gpu_idx}")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")

    actual_lr = lr if lr is not None else (1.0 if opt == "LBFGS" else 1e-4)

    # Build KAN model
    model, model_key = build_kan_model(
        width=width,
        grid=grid,
        k=k,
        seed=seed,
        device=device,
    )
    model_key = f"{model_key}_{opt}"

    num_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)

    # Convert DataSplit numpy arrays to PyTorch tensors
    dataset = {
        "train_input": torch.tensor(data_split.train_x, dtype=torch.float64, device=device),
        "train_label": torch.tensor(data_split.train_y_norm[:, None], dtype=torch.float64, device=device),
        "test_input": torch.tensor(data_split.val_x, dtype=torch.float64, device=device),
        "test_label": torch.tensor(data_split.val_y_norm[:, None], dtype=torch.float64, device=device),
    }

    test_x_tensor = torch.tensor(data_split.test_x, dtype=torch.float64, device=device)
    test_y_norm_tensor = torch.tensor(data_split.test_y_norm[:, None], dtype=torch.float64, device=device)

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)

    start_train = time.time()
    fit_results, stopped_early, epochs_trained = fit_kan_with_early_stopping(
        model=model,
        dataset=dataset,
        opt=opt,
        steps=epochs,
        lr=actual_lr,
        patience=patience,
        min_delta=min_delta,
        monitor=monitor,
        restore_best_weights=restore_best_weights,
    )
    time_elapsed = time.time() - start_train

    # fit_results store RMSE of normalized y; square and multiply by y_std^2 to restore original MSE scale
    train_rmse_min = float(np.min(fit_results["train_loss"]))
    val_rmse_final = float(fit_results["test_loss"][-1])
    min_loss = float((train_rmse_min * data_split.y_std) ** 2)
    val_err = float((val_rmse_final * data_split.y_std) ** 2)

    # Test set evaluation
    start_inf = time.time()
    with torch.no_grad():
        test_pred = model(test_x_tensor)
    inf_latency = time.time() - start_inf

    test_err = float(torch.mean((test_pred - test_y_norm_tensor) ** 2).item() * (data_split.y_std ** 2))

    peak_gpu_mb = 0.0
    if device.type == "cuda":
        peak_gpu_mb = float(torch.cuda.max_memory_allocated(device) / (1024 ** 2))
        torch.cuda.empty_cache()
    gc.collect()

    clean_width = [w[0] if isinstance(w, list) else int(w) for w in width]

    metrics = {
        "Model": model_key,
        "Family": "KAN",
        "Width": clean_width,
        "Grid": int(grid),
        "K": int(k),
        "Optimizer": opt,
        "Learning_Rate": float(actual_lr),
        "Seed": int(seed),
        "Min Loss": float(min_loss),
        "Val Error": float(val_err),
        "Test Error": float(test_err),
        "Time Elapsed": float(time_elapsed),
        "Epochs Trained": int(epochs_trained),
        "Num Parameters": int(num_parameters),
        "Inference Latency": float(inf_latency),
        "Peak GPU Memory (MB)": float(peak_gpu_mb),
        "Early_Stopped": bool(stopped_early),
        "Device": str(device),
        "Status": "SUCCESS",
    }
    metrics.update(data_split.meta)

    return model, metrics
