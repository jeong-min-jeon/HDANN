"""
Kolmogorov-Arnold Network (KAN) module.
PyTorch / pykan environment only.
"""

from .patches import apply_kan_device_patches, ensure_kan_device
from .models import (
    build_kan_model,
    get_simulation_architectures,
    get_realdata_sweep_architectures,
    calculate_kan_theoretical_params,
    PRESET_TOPOLOGIES,
)
from .trainer import fit_kan_with_early_stopping, train_and_evaluate_kan

__all__ = [
    "apply_kan_device_patches",
    "ensure_kan_device",
    "build_kan_model",
    "get_simulation_architectures",
    "get_realdata_sweep_architectures",
    "calculate_kan_theoretical_params",
    "PRESET_TOPOLOGIES",
    "fit_kan_with_early_stopping",
    "train_and_evaluate_kan",
]
