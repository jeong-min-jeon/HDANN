"""
KAN Model Construction and Architectural Sweep Topologies.
PyTorch / pykan environment only.
"""

import copy
from typing import Any, List, Tuple
import torch

from .patches import apply_kan_device_patches, ensure_kan_device

# Automatically apply device patches on module import
apply_kan_device_patches()


def build_kan_model(
    width: List[int],
    grid: int,
    k: int,
    seed: int,
    device: torch.device
) -> Tuple[Any, str]:
    """
    Instantiate a KAN model with device synchronization.
    Returns (kan_model, model_key).
    """
    from kan import KAN

    torch.set_default_dtype(torch.float64)

    clean_width = [w[0] if isinstance(w, list) else int(w) for w in width]
    width_str = "_".join(str(w) for w in clean_width)
    model_key = f"KAN_{width_str}_G{grid}_K{k}"

    kan_init_kwargs = {
        "width": copy.deepcopy(clean_width),
        "grid": grid,
        "k": k,
        "seed": seed,
        "device": device,
    }

    try:
        # pykan 0.2.x: auto_save=False disables automatic disk checkpointing
        model = KAN(**kan_init_kwargs, auto_save=False)
    except TypeError:
        try:
            # pykan 0.1.4: symbolic_enabled=False disables symbolic tracking overhead
            model = KAN(**kan_init_kwargs, symbolic_enabled=False)
        except TypeError:
            # pykan 0.1.2: standard initialization
            model = KAN(**kan_init_kwargs)

    model = ensure_kan_device(model, device)
    return model, model_key


def get_simulation_architectures(d: int) -> List[List[int]]:
    """
    Systematic width and depth sweep architectures for input dimension d.
    Total: 50 distinct topologies across widths 4 to 1024.
    """
    architectures = [
        # Width 4 (depth 1 to 10 hidden layers)
        *[[d] + [4] * i + [1] for i in range(1, 11)],
        # Width 8 (depth 1 to 10 hidden layers)
        *[[d] + [8] * i + [1] for i in range(1, 11)],
        # Width 16 (depth 1 to 9 hidden layers)
        *[[d] + [16] * i + [1] for i in range(1, 10)],
        # Width 32 (depth 1 to 7 hidden layers)
        *[[d] + [32] * i + [1] for i in range(1, 8)],
        # Width 64 (depth 1 to 5 hidden layers)
        *[[d] + [64] * i + [1] for i in range(1, 6)],
        # Width 128 (explicit configurations)
        [d, 128, 1],
        [d, 128, 128, 1],
        [d, 128, 128, 128, 1],
        # Width 256 (depth 1 hidden layer)
        [d, 256, 1],
        # Width 512 (depth 1 hidden layer)
        [d, 512, 1],
    ]
    return architectures


def get_realdata_sweep_architectures(d: int = 8) -> List[List[int]]:
    """
    Systematic width and depth sweep architectures for California Housing (d=8).
    Total: 50 distinct topologies across widths 4 to 512.
    """
    architectures = [
        # Width 4 (depth 1 to 10 hidden layers)
        *[[d] + [4] * i + [1] for i in range(1, 11)],
        # Width 8 (depth 1 to 10 hidden layers)
        *[[d] + [8] * i + [1] for i in range(1, 11)],
        # Width 16 (depth 1 to 9 hidden layers)
        *[[d] + [16] * i + [1] for i in range(1, 10)],
        # Width 32 (depth 1 to 6 hidden layers)
        *[[d] + [32] * i + [1] for i in range(1, 7)],
        # Width 64 (depth 1 to 4 hidden layers)
        *[[d] + [64] * i + [1] for i in range(1, 5)],
        # Width 128
        [d, 128, 1],
    ]
    return architectures


PRESET_TOPOLOGIES = {
    "small": [
        [2], [5], [10], [20], [64],
        [16, 16], [32, 32],
        [16, 16, 16]
    ],
    "medium": [
        [128], [256],
        [64, 64],
        [32, 32, 32], [64, 64, 64]
    ],
    "large": [
        [512],
        [128, 128], [256, 256],
        [128, 128, 128]
    ],
    "huge": [
        [512, 512],
        [1024, 1024],
        [256, 256, 256],
        [512, 512, 512],
        [768, 768, 768],
        [1024, 1024, 1024],
    ]
}


def parse_custom_widths(custom_widths: str) -> List[List[int]]:
    """Parse custom user-defined string (e.g., '64; 128,128; 1024,1024')."""
    topologies = []
    for chunk in custom_widths.split(";"):
        chunk = chunk.strip()
        if not chunk:
            continue
        hidden = [int(x.strip()) for x in chunk.split(",") if x.strip()]
        topologies.append(hidden)
    return topologies


def calculate_kan_theoretical_params(width: List[int], grid: int, k: int) -> int:
    """
    Analytical formula for KAN trainable parameter count:
    P = (G + k + 6) * sum(N_l * N_{l+1})
    """
    clean_w = [w[0] if isinstance(w, list) else int(w) for w in width]
    num_edges = sum(clean_w[l] * clean_w[l + 1] for l in range(len(clean_w) - 1))
    return int(num_edges * (grid + k + 6))
