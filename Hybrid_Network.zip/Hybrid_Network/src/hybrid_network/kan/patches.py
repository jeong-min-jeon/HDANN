"""
Device synchronization patches for pykan 0.1.x and 0.2.x.
Ensures seamless execution across CPU, CUDA, and Apple Silicon MPS.
PyTorch / pykan environment only.
"""

import inspect
import torch


def apply_kan_device_patches() -> None:
    """
    Monkey-patch pykan for CUDA/CPU device synchronization:
    1. kan.spline functions (coef2curve, curve2coef): default device to input tensor device.
    2. KANLayer.update_grid_from_samples: creates torch.arange on target device.
    3. KAN & MultKAN: synchronizes input_id and untracked lists on forward and .to() calls.
    """
    try:
        import kan
    except ImportError:
        return

    # 1. Patch kan.spline functions
    try:
        import kan.spline as kspline
        if hasattr(kspline, "coef2curve"):
            _orig_c2c = kspline.coef2curve
            sig_c2c = inspect.signature(_orig_c2c)

            def _safe_coef2curve(x_eval, grid, coef, k, *args, **kwargs):
                dev = kwargs.pop("device", None)
                if dev is None:
                    dev = x_eval.device
                x_eval = x_eval.to(dev)
                grid = grid.to(dev)
                coef = coef.to(dev)
                if "device" in sig_c2c.parameters:
                    kwargs["device"] = dev
                return _orig_c2c(x_eval, grid, coef, k, *args, **kwargs)

            kspline.coef2curve = _safe_coef2curve

        if hasattr(kspline, "curve2coef"):
            _orig_c2coef = kspline.curve2coef
            sig_c2coef = inspect.signature(_orig_c2coef)

            def _safe_curve2coef(x_eval, y_eval, grid, k, *args, **kwargs):
                dev = kwargs.pop("device", None)
                if dev is None:
                    dev = x_eval.device
                x_eval = x_eval.to(dev)
                y_eval = y_eval.to(dev)
                grid = grid.to(dev)
                if "device" in sig_c2coef.parameters:
                    kwargs["device"] = dev
                if "lamb" not in sig_c2coef.parameters and "lamb" in kwargs:
                    kwargs.pop("lamb")
                return _orig_c2coef(x_eval, y_eval, grid, k, *args, **kwargs)

            kspline.curve2coef = _safe_curve2coef
    except Exception:
        pass

    # 2. Patch KANLayer.update_grid_from_samples & forward
    try:
        from kan.KANLayer import KANLayer

        def _safe_update_grid_from_samples(self, x):
            batch = x.shape[0]
            target_device = x.device
            self.device = target_device

            for p in self.parameters():
                if p.device != target_device:
                    p.data = p.data.to(target_device)
            for b in self.buffers():
                if b.device != target_device:
                    b.data = b.data.to(target_device)
            if hasattr(self, "grid") and isinstance(self.grid, torch.Tensor) and self.grid.device != target_device:
                self.grid.data = self.grid.data.to(target_device)
            if hasattr(self, "coef") and isinstance(self.coef, torch.Tensor) and self.coef.device != target_device:
                self.coef.data = self.coef.data.to(target_device)

            x_pos = torch.sort(x, dim=0)[0]
            import kan.spline as ksp
            y_eval = ksp.coef2curve(x_pos, self.grid, self.coef, self.k, device=target_device)
            num_interval = self.grid.shape[1] - 1 - 2 * self.k
            ids = [int(batch / num_interval * i) for i in range(num_interval)] + [-1]
            grid_adaptive = x_pos[ids, :].permute(1, 0)
            h = (grid_adaptive[:, [-1]] - grid_adaptive[:, [0]]) / num_interval

            grid_uniform = grid_adaptive[:, [0]] + h * torch.arange(
                num_interval + 1, device=target_device, dtype=grid_adaptive.dtype
            )[None, :]
            grid = self.grid_eps * grid_uniform + (1 - self.grid_eps) * grid_adaptive

            def _local_extend_grid(g, k_ext=0):
                h_step = (g[:, [-1]] - g[:, [0]]) / (g.shape[1] - 1)
                for _ in range(k_ext):
                    g = torch.cat([g[:, [0]] - h_step, g], dim=1)
                    g = torch.cat([g, g[:, [-1]] + h_step], dim=1)
                return g

            self.grid.data = _local_extend_grid(grid, k_ext=self.k).to(target_device)
            try:
                self.coef.data = ksp.curve2coef(x_pos, y_eval, self.grid, self.k, device=target_device).to(target_device)
            except TypeError:
                self.coef.data = ksp.curve2coef(x_pos, y_eval, self.grid, self.k).to(target_device)

        KANLayer.update_grid_from_samples = _safe_update_grid_from_samples

        _orig_layer_forward = KANLayer.forward
        def _safe_layer_forward(self, x, *args, **kwargs):
            target_device = x.device
            self.device = target_device
            if hasattr(self, "grid") and self.grid.device != target_device:
                self.grid.data = self.grid.data.to(target_device)
            if hasattr(self, "coef") and self.coef.device != target_device:
                self.coef.data = self.coef.data.to(target_device)
            if hasattr(self, "scale_base") and self.scale_base.device != target_device:
                self.scale_base.data = self.scale_base.data.to(target_device)
            if hasattr(self, "scale_sp") and self.scale_sp.device != target_device:
                self.scale_sp.data = self.scale_sp.data.to(target_device)
            if hasattr(self, "mask") and self.mask.device != target_device:
                self.mask.data = self.mask.data.to(target_device)
            return _orig_layer_forward(self, x, *args, **kwargs)
        KANLayer.forward = _safe_layer_forward
    except Exception:
        pass

    # 3. Patch KAN & MultKAN forward and to methods
    def _sync_model_to_device(model, target_device):
        model.device = target_device
        if hasattr(model, "input_id") and isinstance(model.input_id, torch.Tensor):
            if model.input_id.device != target_device:
                model.input_id = model.input_id.to(target_device)

        for attr in ["node_bias", "subnode_bias", "node_scale", "subnode_scale"]:
            if hasattr(model, attr):
                lst = getattr(model, attr)
                if isinstance(lst, list):
                    for i in range(len(lst)):
                        if isinstance(lst[i], torch.Tensor) and lst[i].device != target_device:
                            lst[i] = lst[i].to(target_device)

        for _, param in model.named_parameters():
            if param.device != target_device:
                param.data = param.data.to(target_device)
        for _, buf in model.named_buffers():
            if buf.device != target_device:
                buf.data = buf.data.to(target_device)

        if hasattr(model, "act_fun"):
            for layer in model.act_fun:
                layer.device = target_device
                if hasattr(layer, "grid") and isinstance(layer.grid, torch.Tensor) and layer.grid.device != target_device:
                    layer.grid.data = layer.grid.data.to(target_device)
                if hasattr(layer, "coef") and isinstance(layer.coef, torch.Tensor) and layer.coef.device != target_device:
                    layer.coef.data = layer.coef.data.to(target_device)
                if hasattr(layer, "scale_base") and isinstance(layer.scale_base, torch.Tensor) and layer.scale_base.device != target_device:
                    layer.scale_base.data = layer.scale_base.data.to(target_device)
                if hasattr(layer, "scale_sp") and isinstance(layer.scale_sp, torch.Tensor) and layer.scale_sp.device != target_device:
                    layer.scale_sp.data = layer.scale_sp.data.to(target_device)
                if hasattr(layer, "mask") and isinstance(layer.mask, torch.Tensor) and layer.mask.device != target_device:
                    layer.mask.data = layer.mask.data.to(target_device)

        if hasattr(model, "symbolic_fun"):
            for s_layer in model.symbolic_fun:
                s_layer.device = target_device
                for p in s_layer.parameters():
                    if p.device != target_device:
                        p.data = p.data.to(target_device)

    def _wrap_forward(orig_fwd):
        def _fwd(self, x, *args, **kwargs):
            _sync_model_to_device(self, x.device)
            return orig_fwd(self, x, *args, **kwargs)
        return _fwd

    def _wrap_to(orig_to):
        def _to(self, *args, **kwargs):
            res = orig_to(self, *args, **kwargs)
            target = args[0] if len(args) > 0 else kwargs.get("device", None)
            if target is not None:
                if isinstance(target, (str, int)):
                    target = torch.device(target if isinstance(target, str) else f"cuda:{target}")
                _sync_model_to_device(self, target)
            return res
        return _to

    classes_to_patch = []
    if hasattr(kan, "KAN"):
        classes_to_patch.append(kan.KAN)
    try:
        from kan.MultKAN import MultKAN
        if MultKAN not in classes_to_patch:
            classes_to_patch.append(MultKAN)
    except Exception:
        pass

    for cls in classes_to_patch:
        if hasattr(cls, "forward"):
            cls.forward = _wrap_forward(cls.forward)
        if hasattr(cls, "to"):
            cls.to = _wrap_to(cls.to)


def ensure_kan_device(model: torch.nn.Module, device: torch.device) -> torch.nn.Module:
    """Explicitly move all internal parameters, buffers, and unregistered lists to target device."""
    model.to(device)
    model.device = device

    if hasattr(model, "input_id") and isinstance(model.input_id, torch.Tensor):
        model.input_id = model.input_id.to(device)

    for attr in ["node_bias", "subnode_bias", "node_scale", "subnode_scale"]:
        if hasattr(model, attr):
            lst = getattr(model, attr)
            if isinstance(lst, list):
                for i in range(len(lst)):
                    if isinstance(lst[i], torch.Tensor):
                        lst[i] = lst[i].to(device)

    for param in model.parameters():
        if param.device != device:
            param.data = param.data.to(device)
    for buf in model.buffers():
        if buf.device != device:
            buf.data = buf.data.to(device)

    if hasattr(model, "act_fun"):
        for layer in model.act_fun:
            layer.to(device)
            layer.device = device
            if hasattr(layer, "grid") and isinstance(layer.grid, torch.Tensor):
                layer.grid.data = layer.grid.data.to(device)
            if hasattr(layer, "coef") and isinstance(layer.coef, torch.Tensor):
                layer.coef.data = layer.coef.data.to(device)
            if hasattr(layer, "scale_base") and isinstance(layer.scale_base, torch.Tensor):
                layer.scale_base.data = layer.scale_base.data.to(device)
            if hasattr(layer, "scale_sp") and isinstance(layer.scale_sp, torch.Tensor):
                layer.scale_sp.data = layer.scale_sp.data.to(device)
            if hasattr(layer, "mask") and isinstance(layer.mask, torch.Tensor):
                layer.mask.data = layer.mask.data.to(device)

    if hasattr(model, "symbolic_fun"):
        for s_layer in model.symbolic_fun:
            s_layer.to(device)
            s_layer.device = device
            for p in s_layer.parameters():
                if p.device != device:
                    p.data = p.data.to(device)

    return model
