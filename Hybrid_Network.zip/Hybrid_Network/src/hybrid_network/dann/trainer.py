"""
Direct model training and unscaled metric evaluation for DANN and HDANN.
Returns (trained_keras_model, metrics_dict).
TensorFlow / Keras environment only.
"""

import time
from typing import Any, Dict, Optional, Tuple
import numpy as np

from ..data.synthetic import DataSplit
from ..utils.seed import set_dann_seed
from .models import build_dann_model


def train_and_evaluate_dann(
    arch_name: str,
    num_layer: int,
    unit_size: int,
    max_order: int = 0,
    data_split: DataSplit = None,
    seed: int = 702,
    activation: str = "ReLU",
    base_type: str = "FS",
    epochs: int = 5000,
    lr: float = 1e-4,
    batch_size: int = 512,
    steps_per_execution: int = 4,
    jit_compile: bool = False,
    patience: int = 10,
    min_delta: float = 1e-3,
    gpu_id: Optional[str] = "0",
    strict_determinism: bool = False,
    verbose: int = 0,
) -> Tuple[Any, Dict[str, Any]]:
    """
    Train a single DANN or HDANN model on a DataSplit and return (model, metrics_dict).
    Evaluation metrics (Min Loss, Val Error, Test Error) are unnormalized using (* y_std^2).
    """
    import tensorflow as tf

    set_dann_seed(seed=seed, strict_determinism=strict_determinism)

    # Configure GPU memory growth if GPU is available
    gpus = tf.config.list_physical_devices("GPU")
    if gpus and gpu_id is not None and gpu_id.strip().lower() != "cpu":
        try:
            idx = int(gpu_id)
            if idx < len(gpus):
                tf.config.set_visible_devices(gpus[idx], "GPU")
                tf.config.experimental.set_memory_growth(gpus[idx], True)
        except Exception:
            pass

    # Build model architecture
    model, model_key = build_dann_model(
        arch_name=arch_name,
        data_shape=data_split.input_dim,
        num_layer=num_layer,
        unit_size=unit_size,
        max_order=max_order,
        activation=activation,
        base_type=base_type,
    )

    num_parameters = int(model.count_params())

    # Build tf.data pipeline
    train_x = data_split.train_x.astype(np.float32)
    train_y_norm = data_split.train_y_norm.astype(np.float32)

    train_size = len(train_x)
    num_batches = (train_size + batch_size - 1) // batch_size
    steps_per_exec = min(steps_per_execution, max(1, num_batches))

    train_ds = (
        tf.data.Dataset.from_tensor_slices((train_x, train_y_norm))
        .cache()
        .batch(batch_size)
        .prefetch(tf.data.AUTOTUNE)
    )

    val_x_tensor = tf.convert_to_tensor(data_split.val_x, dtype=tf.float64)
    val_y_norm_tensor = tf.convert_to_tensor(data_split.val_y_norm, dtype=tf.float64)
    test_x_tensor = tf.convert_to_tensor(data_split.test_x, dtype=tf.float64)
    test_y_norm_tensor = tf.convert_to_tensor(data_split.test_y_norm, dtype=tf.float64)

    early_stopping_callback = tf.keras.callbacks.EarlyStopping(
        monitor="loss",
        patience=patience,
        min_delta=min_delta,
        restore_best_weights=True,
    )

    # Compile with auto-fallback for jit_compile
    try:
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
            loss=tf.keras.losses.MeanSquaredError(),
            jit_compile=jit_compile,
            steps_per_execution=steps_per_exec,
        )
    except Exception:
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
            loss=tf.keras.losses.MeanSquaredError(),
            jit_compile=False,
            steps_per_execution=steps_per_exec,
        )

    # Reset GPU memory stats
    try:
        tf.config.experimental.reset_memory_stats("GPU:0")
    except Exception:
        pass

    start_time = time.time()
    history = model.fit(
        train_ds,
        epochs=epochs,
        callbacks=[early_stopping_callback],
        verbose=verbose,
    )
    time_elapsed = time.time() - start_time
    epochs_trained = len(history.history["loss"])
    min_loss = float(min(history.history["loss"]) * (data_split.y_std ** 2))

    # Inference evaluation
    start_inf = time.time()
    test_pred = tf.cast(model(test_x_tensor, training=False), tf.float64)
    inf_latency = time.time() - start_inf

    val_pred = tf.cast(model(val_x_tensor, training=False), tf.float64)

    val_err = float(
        tf.reduce_mean(tf.square(val_y_norm_tensor - tf.squeeze(val_pred, axis=-1))).numpy()
        * (data_split.y_std ** 2)
    )
    test_err = float(
        tf.reduce_mean(tf.square(test_y_norm_tensor - tf.squeeze(test_pred, axis=-1))).numpy()
        * (data_split.y_std ** 2)
    )

    try:
        mem_info = tf.config.experimental.get_memory_info("GPU:0")
        peak_gpu_mb = float(mem_info["peak"] / (1024 ** 2))
    except Exception:
        peak_gpu_mb = 0.0

    metrics = {
        "Model": model_key,
        "Architecture": arch_name,
        "Num_Layer": int(num_layer),
        "Unit_Size": int(unit_size),
        "Max_Order": int(max_order),
        "Activation": activation,
        "Base_Type": base_type,
        "Seed": int(seed),
        "Min Loss": float(min_loss),
        "Val Error": float(val_err),
        "Test Error": float(test_err),
        "Time Elapsed": float(time_elapsed),
        "Epochs Trained": int(epochs_trained),
        "Num Parameters": int(num_parameters),
        "Inference Latency": float(inf_latency),
        "Peak GPU Memory (MB)": float(peak_gpu_mb),
        "Status": "SUCCESS",
    }
    # Attach data metadata (e.g., Model_Type, Scenario, or Split)
    metrics.update(data_split.meta)

    return model, metrics
