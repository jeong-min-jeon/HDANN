"""
DANN and HDANN Architecture Definitions with Zero-Overhead FS Basis Expansion.
Optimized with tf.reshape and float64 spline basis precision.
TensorFlow / Keras environment only.
"""

from typing import Any, Dict, Tuple


def create_apply_base_layer_class():
    """Factory creating the ApplyBaseLayer class with imported TensorFlow."""
    import tensorflow as tf

    class ApplyBaseLayer(tf.keras.layers.Layer):
        """
        FS Basis Expansion Layer.
        Strictly restricted to FS basis as specified in research requirements.
        Optimized with zero-overhead tf.reshape flattening.
        """
        def __init__(self, max_order: int, base_type: str = "FS", **kwargs):
            super(ApplyBaseLayer, self).__init__(**kwargs)
            self.max_order = max_order
            self.base_type = base_type

            if base_type != "FS":
                raise ValueError(f"Basis type '{base_type}' is disabled. Only 'FS' is supported.")

            edge_list = []
            slope_list = []

            # k = -1, i = 1
            slope_list.append(-1.0)
            edge_list.append(1.0)

            for order in range(2, max_order + 1):
                k = order - 2
                num_subs = 2**k
                for i in range(1, num_subs + 1):
                    slopek = k + 1
                    slope = -(2.0 ** slopek)
                    edge = (2.0 * i - 1.0) / (2.0 ** slopek)
                    edge_list.append(edge)
                    slope_list.append(slope)

            self.num_bases = len(edge_list)
            self.edges = tf.reshape(tf.constant(edge_list, dtype=tf.float64), (1, -1, 1))
            self.slopes = tf.reshape(tf.constant(slope_list, dtype=tf.float64), (1, -1, 1))

        def call(self, inputs):
            # inputs shape: (batch_size, num_features)
            x = tf.expand_dims(tf.cast(inputs, tf.float64), axis=1)  # (batch, 1, num_features)
            stacked = tf.maximum(tf.abs(x - self.edges) * self.slopes + 1.0, 0.0)

            batch_size = tf.shape(inputs)[0]
            num_features = inputs.shape[-1]
            out_dim = self.num_bases * num_features if num_features is not None else -1
            return tf.reshape(stacked, shape=(batch_size, out_dim))

        def compute_output_shape(self, input_shape):
            num_features = input_shape[-1]
            out_dim = self.num_bases * num_features if num_features is not None else None
            return (input_shape[0], out_dim)

        def get_config(self):
            config = super().get_config()
            config.update({
                "max_order": self.max_order,
                "base_type": self.base_type,
            })
            return config

    return ApplyBaseLayer


def apply_activation_hdann(outputs, activation: str):
    """Activation selection for Hierarchical DANN architectures."""
    import tensorflow as tf
    if activation == "ReLU":
        return tf.keras.layers.ReLU()(outputs)
    elif activation == "tanh":
        return tf.keras.activations.tanh(outputs)
    else:
        return tf.keras.activations.sigmoid(outputs)


def apply_activation_dnn(outputs, activation: str):
    """Activation selection for standard DNN architecture."""
    import tensorflow as tf
    if activation == "ReLU":
        return tf.keras.layers.ReLU()(outputs)
    elif activation == "elu":
        return tf.keras.activations.elu(outputs)
    elif activation == "tanh":
        return tf.keras.activations.tanh(outputs)
    else:
        return tf.keras.activations.sigmoid(outputs)


def DNN(num_layer: int, unit_size: int, activation: str, data_shape: int = 6):
    """Standard Deep Neural Network (MLP) baseline."""
    import tensorflow as tf
    inputs = tf.keras.Input(shape=(data_shape,), dtype="float32")
    outputs = inputs
    for _ in range(num_layer):
        outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
        outputs = apply_activation_dnn(outputs, activation)
    outputs = tf.keras.layers.Dense(units=1)(outputs)
    return tf.keras.Model(inputs, outputs)


def DANN(num_layer: int, max_order: int, unit_size: int, base_type: str = "FS", data_shape: int = 6):
    """Deep Additive Neural Network with repetitive FS basis expansions."""
    import tensorflow as tf
    ApplyBaseLayer = create_apply_base_layer_class()
    inputs = tf.keras.Input(shape=(data_shape,), dtype="float32")
    outputs = inputs
    for _ in range(num_layer):
        outputs = ApplyBaseLayer(max_order, base_type)(outputs)
        outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
        outputs = tf.keras.activations.sigmoid(outputs)
    outputs = ApplyBaseLayer(max_order, base_type)(outputs)
    outputs = tf.keras.layers.Dense(units=1)(outputs)
    return tf.keras.Model(inputs, outputs)


def HDANN_1(num_layer: int, unit_size: int, activation: str, max_order: int, base_type: str = "FS", data_shape: int = 6):
    """Hierarchical DANN Type 1: FS Basis at the input layer, followed by standard DNN layers."""
    if num_layer < 2:
        raise ValueError(f"HDANN_1 requires num_layer >= 2 (got {num_layer}) for a hybrid architecture.")
    import tensorflow as tf
    ApplyBaseLayer = create_apply_base_layer_class()
    inputs = tf.keras.Input(shape=(data_shape,), dtype="float32")
    outputs = inputs
    outputs = ApplyBaseLayer(max_order, base_type)(outputs)
    outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
    outputs = apply_activation_hdann(outputs, activation)
    for _ in range(num_layer - 1):
        outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
        outputs = apply_activation_hdann(outputs, activation)
    outputs = tf.keras.layers.Dense(units=1)(outputs)
    return tf.keras.Model(inputs, outputs)


def HDANN_2(num_layer: int, unit_size: int, activation: str, max_order: int, base_type: str = "FS", data_shape: int = 6):
    """Hierarchical DANN Type 2: Standard DNN layers, followed by FS Basis before the output layer."""
    if num_layer < 2:
        raise ValueError(f"HDANN_2 requires num_layer >= 2 (got {num_layer}) for a hybrid architecture.")
    import tensorflow as tf
    ApplyBaseLayer = create_apply_base_layer_class()
    inputs = tf.keras.Input(shape=(data_shape,), dtype="float32")
    outputs = inputs
    for _ in range(num_layer - 1):
        outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
        outputs = apply_activation_hdann(outputs, activation)
    outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
    outputs = tf.keras.activations.sigmoid(outputs)
    outputs = ApplyBaseLayer(max_order, base_type)(outputs)
    outputs = tf.keras.layers.Dense(units=1)(outputs)
    return tf.keras.Model(inputs, outputs)


def HDANN_3(num_layer: int, unit_size: int, activation: str, max_order: int, base_type: str = "FS", data_shape: int = 6):
    """Hierarchical DANN Type 3: FS Basis at input AND output layers, with intermediate DNN layers."""
    if num_layer < 3:
        raise ValueError(f"HDANN_3 requires num_layer >= 3 (got {num_layer}) to have intermediate DNN layers.")
    import tensorflow as tf
    ApplyBaseLayer = create_apply_base_layer_class()
    inputs = tf.keras.Input(shape=(data_shape,), dtype="float32")
    outputs = inputs
    outputs = ApplyBaseLayer(max_order, base_type)(outputs)
    outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
    outputs = tf.keras.activations.sigmoid(outputs)
    for _ in range(num_layer - 2):
        outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
        outputs = apply_activation_hdann(outputs, activation)
    outputs = tf.keras.layers.Dense(units=unit_size)(outputs)
    outputs = tf.keras.activations.sigmoid(outputs)
    outputs = ApplyBaseLayer(max_order, base_type)(outputs)
    outputs = tf.keras.layers.Dense(units=1)(outputs)
    return tf.keras.Model(inputs, outputs)


MODEL_BUILDERS = {
    "DNN": DNN,
    "DANN": DANN,
    "HDANN_1": HDANN_1,
    "HDANN_2": HDANN_2,
    "HDANN_3": HDANN_3,
    "HDANN1": HDANN_1,
    "HDANN2": HDANN_2,
    "HDANN3": HDANN_3,
}


def build_dann_model(
    arch_name: str,
    data_shape: int,
    num_layer: int,
    unit_size: int,
    max_order: int = 0,
    activation: str = "ReLU",
    base_type: str = "FS"
) -> Tuple[Any, str]:
    """
    Direct model builder helper.
    Returns (keras_model, model_key).
    """
    clean_name = arch_name.upper().replace("-", "_")
    if clean_name not in MODEL_BUILDERS:
        raise ValueError(f"Unknown DANN architecture: {arch_name}. Supported: {list(MODEL_BUILDERS.keys())}")

    builder_fn = MODEL_BUILDERS[clean_name]

    if clean_name == "DNN":
        model = builder_fn(
            num_layer=num_layer,
            unit_size=unit_size,
            activation=activation,
            data_shape=data_shape,
        )
        model_key = f"DNN_{num_layer}_{unit_size}_{activation}"
    elif clean_name == "DANN":
        model = builder_fn(
            num_layer=num_layer,
            max_order=max_order,
            unit_size=unit_size,
            base_type=base_type,
            data_shape=data_shape
        )
        model_key = f"DANN_{num_layer}_{unit_size}_{max_order}_{base_type}"
    else:
        prefix = "HDANN1" if "1" in clean_name else ("HDANN2" if "2" in clean_name else "HDANN3")
        model = builder_fn(
            num_layer=num_layer,
            unit_size=unit_size,
            activation=activation,
            max_order=max_order,
            base_type=base_type,
            data_shape=data_shape
        )
        model_key = f"{prefix}_{num_layer}_{unit_size}_{max_order}_{base_type}_{activation}"

    return model, model_key
