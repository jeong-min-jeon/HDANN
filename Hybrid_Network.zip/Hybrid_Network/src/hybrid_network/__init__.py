"""
Hybrid_Network: Research codebase for Deep Additive Neural Networks (DANN / HDANN)
and Kolmogorov-Arnold Networks (KAN) Benchmarks.
"""

__version__ = "1.0.0"
