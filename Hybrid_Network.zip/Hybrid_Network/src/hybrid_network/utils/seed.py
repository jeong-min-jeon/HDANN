"""
Framework-isolated seed management for exact experiment reproducibility.
Guarantees bitwise reproducibility across Python, NumPy, TensorFlow, and PyTorch.
"""

import os
import random
import numpy as np


def set_dann_seed(seed: int, strict_determinism: bool = False) -> None:
    """
    Seed random number generators for TensorFlow/Keras environment (DANN/HDANN).
    Does NOT import or touch PyTorch.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)

    if strict_determinism:
        os.environ["TF_DETERMINISTIC_OPS"] = "1"
        os.environ["TF_CUDNN_DETERMINISTIC"] = "1"
    else:
        os.environ["TF_DETERMINISTIC_OPS"] = "0"
        os.environ["TF_CUDNN_DETERMINISTIC"] = "0"

    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        if strict_determinism:
            try:
                tf.config.experimental.enable_op_determinism()
            except AttributeError:
                pass
    except ImportError:
        pass


def set_kan_seed(seed: int, strict_determinism: bool = False) -> None:
    """
    Seed random number generators for PyTorch/pykan environment (KAN).
    Does NOT import or touch TensorFlow.
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)

    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
            if strict_determinism:
                os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
                torch.backends.cudnn.deterministic = True
                torch.backends.cudnn.benchmark = False
                try:
                    torch.use_deterministic_algorithms(True)
                except Exception:
                    pass
    except ImportError:
        pass
