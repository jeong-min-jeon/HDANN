"""
Standardized artifact persistence for JSON run records and CSV metric summaries.
"""

import json
import os
from pathlib import Path
from typing import Any, Dict, List


def save_json_result(filepath: str, result_dict: Dict[str, Any]) -> None:
    """Save run metrics dictionary to JSON file."""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(result_dict, f, indent=4)


def append_summary_csv(csv_path: str, row_dict: Dict[str, Any], column_order: List[str]) -> None:
    """
    Append a row of metrics to a summary CSV file.
    Creates the file and writes the header if it does not yet exist.
    """
    path = Path(csv_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    
    file_exists = path.exists()
    with open(path, "a", encoding="utf-8") as f:
        if not file_exists:
            f.write(",".join(column_order) + "\n")
        
        row_values = []
        for col in column_order:
            val = row_dict.get(col, "")
            if isinstance(val, float):
                row_values.append(f"{val:.6f}")
            elif isinstance(val, (list, tuple)):
                row_values.append(f'"{list(val)}"')
            else:
                row_values.append(str(val))
        f.write(",".join(row_values) + "\n")
        f.flush()


def update_best_model_csv(csv_path: str, best_models: Dict[Any, Dict[str, Any]], column_order: List[str]) -> None:
    """
    Rewrite the best-model summary CSV with the lowest validation error runs.
    """
    path = Path(csv_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        f.write(",".join(column_order) + "\n")
        for key in sorted(best_models.keys(), key=lambda k: str(k)):
            b = best_models[key]
            row_values = []
            for col in column_order:
                val = b.get(col, "")
                if isinstance(val, float):
                    row_values.append(f"{val:.6f}")
                elif isinstance(val, (list, tuple)):
                    row_values.append(f'"{list(val)}"')
                else:
                    row_values.append(str(val))
            f.write(",".join(row_values) + "\n")
            f.flush()
