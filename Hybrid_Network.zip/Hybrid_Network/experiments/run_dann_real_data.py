#!/usr/bin/env python3
"""
Full Real-World Benchmark Reproduction Script for DANN & HDANN (California Housing 5-Fold CV).
TensorFlow / Keras environment only.
No argparse: Loads settings from configs/dann_real_data.yaml or HYBRID_CONFIG.
"""

import json
import os
import sys
import time
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

import tensorflow as tf
from hybrid_network.config import DANNRealDataConfig, load_config
from hybrid_network.data.housing import prepare_housing_split
from hybrid_network.dann.trainer import train_and_evaluate_dann
from hybrid_network.utils.io import append_summary_csv, save_json_result

COLUMNS = [
    "Model", "Split", "Dataset", "Min Loss", "Val Error",
    "Test Error", "Time Elapsed", "Epochs Trained", "Num Parameters",
    "Inference Latency", "Peak GPU Memory (MB)"
]


def main():
    cfg = load_config(DANNRealDataConfig, "configs/dann_real_data.yaml")
    out_dir = Path(cfg.output_dir)
    if not out_dir.is_absolute():
        out_dir = PROJECT_ROOT / cfg.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    data_path = Path(cfg.data_path)
    if not data_path.is_absolute():
        data_path = PROJECT_ROOT / cfg.data_path

    global_csv = out_dir / "summary_realdata_all.csv"

    print("=" * 75)
    print("DANN & HDANN Real Data Benchmark Runner (California Housing 5-Fold CV)")
    print(f"  Dataset Path:         {cfg.data_path}")
    print(f"  Output Directory:     {out_dir}")
    print(f"  Active Splits:        {cfg.splits}")
    print(f"  Epochs / LearningRate:{cfg.epochs} / {cfg.lr}")
    print(f"  Patience / MinDelta:  {cfg.patience} / {cfg.min_delta}")
    print("=" * 75)

    data_cache = {}
    total_trained = 0
    total_skipped = 0
    start_total_time = time.time()

    hdann_layers = [l for l in cfg.num_layer_list if l >= 2]
    hdann3_layers = [l for l in cfg.num_layer_list if l >= 3]
    orders = [o for o in cfg.orders if o > 1]

    for split in cfg.splits:
        split_csv = out_dir / f"summary_realdata_split_{split}.csv"
        split_seed = 2024 + ord(split.upper()) - ord("A")

        if split not in data_cache:
            data_cache[split] = prepare_housing_split(
                data_path=str(data_path),
                split=split,
                seed=2024
            )
        data_split = data_cache[split]

        # 1. DANN
        for num_layer in cfg.num_layer_list:
            for unit_size in cfg.unit_size_list:
                for max_order in orders:
                    m_key = f"DANN_{num_layer}_{unit_size}_{max_order}_FS"
                    res_file = out_dir / f"{m_key}_split{split}.json"

                    if res_file.exists():
                        total_skipped += 1
                        continue

                    try:
                        _, metrics = train_and_evaluate_dann(
                            arch_name="DANN",
                            num_layer=num_layer,
                            unit_size=unit_size,
                            max_order=max_order,
                            data_split=data_split,
                            seed=split_seed,
                            epochs=cfg.epochs,
                            lr=cfg.lr,
                            batch_size=cfg.batch_size,
                            steps_per_execution=cfg.steps_per_execution,
                            jit_compile=cfg.jit_compile,
                            patience=cfg.patience,
                            min_delta=cfg.min_delta,
                            gpu_id=cfg.gpu_id,
                            strict_determinism=cfg.strict_determinism,
                            verbose=0
                        )
                        save_json_result(str(res_file), metrics)
                        append_summary_csv(str(global_csv), metrics, COLUMNS)
                        append_summary_csv(str(split_csv), metrics, COLUMNS)
                        total_trained += 1
                        print(f"[Split {split}] {m_key:36s} | ValErr: {metrics['Val Error']:8.4f} | TestErr: {metrics['Test Error']:8.4f} | {metrics['Time Elapsed']:5.2f}s")
                    finally:
                        tf.keras.backend.clear_session()

        # 2. HDANN_1, HDANN_2
        for arch in ["HDANN_1", "HDANN_2"]:
            prefix = "HDANN1" if "1" in arch else "HDANN2"
            for num_layer in hdann_layers:
                for unit_size in cfg.unit_size_list:
                    for act in cfg.activation_list:
                        for max_order in orders:
                            m_key = f"{prefix}_{num_layer}_{unit_size}_{max_order}_FS_{act}"
                            res_file = out_dir / f"{m_key}_split{split}.json"

                            if res_file.exists():
                                total_skipped += 1
                                continue

                            try:
                                _, metrics = train_and_evaluate_dann(
                                    arch_name=arch,
                                    num_layer=num_layer,
                                    unit_size=unit_size,
                                    max_order=max_order,
                                    activation=act,
                                    data_split=data_split,
                                    seed=split_seed,
                                    epochs=cfg.epochs,
                                    lr=cfg.lr,
                                    batch_size=cfg.batch_size,
                                    steps_per_execution=cfg.steps_per_execution,
                                    jit_compile=cfg.jit_compile,
                                    patience=cfg.patience,
                                    min_delta=cfg.min_delta,
                                    gpu_id=cfg.gpu_id,
                                    strict_determinism=cfg.strict_determinism,
                                    verbose=0
                                )
                                save_json_result(str(res_file), metrics)
                                append_summary_csv(str(global_csv), metrics, COLUMNS)
                                append_summary_csv(str(split_csv), metrics, COLUMNS)
                                total_trained += 1
                                print(f"[Split {split}] {m_key:36s} | ValErr: {metrics['Val Error']:8.4f} | TestErr: {metrics['Test Error']:8.4f} | {metrics['Time Elapsed']:5.2f}s")
                            finally:
                                tf.keras.backend.clear_session()

        # 3. HDANN_3
        for num_layer in hdann3_layers:
            for unit_size in cfg.unit_size_list:
                for act in cfg.activation_list:
                    for max_order in orders:
                        m_key = f"HDANN3_{num_layer}_{unit_size}_{max_order}_FS_{act}"
                        res_file = out_dir / f"{m_key}_split{split}.json"

                        if res_file.exists():
                            total_skipped += 1
                            continue

                        try:
                            _, metrics = train_and_evaluate_dann(
                                arch_name="HDANN_3",
                                num_layer=num_layer,
                                unit_size=unit_size,
                                max_order=max_order,
                                activation=act,
                                data_split=data_split,
                                seed=split_seed,
                                epochs=cfg.epochs,
                                lr=cfg.lr,
                                batch_size=cfg.batch_size,
                                steps_per_execution=cfg.steps_per_execution,
                                jit_compile=cfg.jit_compile,
                                patience=cfg.patience,
                                min_delta=cfg.min_delta,
                                gpu_id=cfg.gpu_id,
                                strict_determinism=cfg.strict_determinism,
                                verbose=0
                            )
                            save_json_result(str(res_file), metrics)
                            append_summary_csv(str(global_csv), metrics, COLUMNS)
                            append_summary_csv(str(split_csv), metrics, COLUMNS)
                            total_trained += 1
                            print(f"[Split {split}] {m_key:36s} | ValErr: {metrics['Val Error']:8.4f} | TestErr: {metrics['Test Error']:8.4f} | {metrics['Time Elapsed']:5.2f}s")
                        finally:
                            tf.keras.backend.clear_session()

    total_time = time.time() - start_total_time
    print("\n" + "=" * 75)
    print(f"Real Data Suite Complete: Trained {total_trained} models, Skipped {total_skipped} existing.")
    print(f"Total Runtime: {total_time:.2f}s ({total_time / 3600:.2f} hours)")
    print(f"Results saved in: {out_dir}")
    print("=" * 75)


if __name__ == "__main__":
    main()
