#!/usr/bin/env python3
"""
Full Simulation Benchmark Reproduction Script for KAN (Models 1, 2, 3, 4).
PyTorch / pykan environment only.
No argparse: Loads settings from configs/kan_simulation.yaml or HYBRID_CONFIG.
"""

import gc
import json
import os
import sys
import time
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

import torch
from hybrid_network.config import KANSimulationConfig, load_config
from hybrid_network.data.synthetic import prepare_synthetic_split
from hybrid_network.kan.models import get_simulation_architectures, parse_custom_widths
from hybrid_network.kan.trainer import train_and_evaluate_kan
from hybrid_network.utils.io import append_summary_csv, save_json_result, update_best_model_csv

COLUMNS = [
    "Model", "Model_Type", "Scenario", "Seed", "Width", "Grid", "K",
    "Num Parameters", "Min Loss", "Val Error", "Test Error", "Time Elapsed",
    "Epochs Trained", "Inference Latency", "Peak GPU Memory (MB)", "Optimizer", "Device"
]

BEST_COLUMNS = [
    "Model", "Model_Type", "Scenario", "Seed", "Width", "Grid", "K",
    "Num Parameters", "Min Loss", "Val Error", "Test Error", "Time Elapsed",
    "Epochs Trained", "Peak GPU Memory (MB)", "Optimizer"
]


def main():
    cfg = load_config(KANSimulationConfig, "configs/kan_simulation.yaml")
    out_dir = Path(cfg.output_dir)
    if not out_dir.is_absolute():
        out_dir = PROJECT_ROOT / cfg.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    global_csv = out_dir / "summary_kan_all.csv"
    best_csv = out_dir / "best_kan_results.csv"

    print("=" * 75)
    print("KAN Simulation Benchmark Runner (Sequential Execution)")
    print(f"  Output Directory:     {out_dir}")
    print(f"  Model Types:          {cfg.model_types}")
    print(f"  Scenarios:            {cfg.scenarios}")
    print(f"  Seeds:                {cfg.seeds}")
    print(f"  Spline Grids / Orders:{cfg.grids} / {cfg.ks}")
    print(f"  Optimizer / LR:       {cfg.opt} / {cfg.lr}")
    print(f"  Device:               {cfg.device}")
    print("=" * 75)

    data_cache = {}
    best_models = {}
    total_trained = 0
    total_skipped = 0
    start_total_time = time.time()

    for model_type in cfg.model_types:
        model_csv = out_dir / f"summary_kan_model_{model_type}.csv"
        d = 8 if model_type == 4 else 6

        if cfg.custom_widths:
            hidden_topos = parse_custom_widths(cfg.custom_widths)
            kan_widths = [[d] + h + [1] for h in hidden_topos]
        else:
            kan_widths = get_simulation_architectures(d)

        for scenario in cfg.scenarios:
            for seed in cfg.seeds:
                cache_key = (model_type, scenario, seed)
                if cache_key not in data_cache:
                    data_cache[cache_key] = prepare_synthetic_split(
                        model_type=model_type,
                        scenario=scenario,
                        seed=seed
                    )
                data_split = data_cache[cache_key]

                for width in kan_widths:
                    clean_w = [w[0] if isinstance(w, list) else int(w) for w in width]
                    width_tag = "_".join(str(w) for w in clean_w)

                    for grid in cfg.grids:
                        for k in cfg.ks:
                            m_key = f"KAN_{width_tag}_G{grid}_K{k}_{cfg.opt}"
                            res_file = out_dir / f"{m_key}_model{model_type}_scenario{scenario}_seed{seed}.json"

                            if res_file.exists():
                                try:
                                    with open(res_file, "r", encoding="utf-8") as f:
                                        existing_data = json.load(f)
                                    if existing_data.get("Status") == "SUCCESS":
                                        total_skipped += 1
                                        # Track best model if existing
                                        val_e = existing_data.get("Val Error", float("inf"))
                                        if cache_key not in best_models or val_e < best_models[cache_key].get("Val Error", float("inf")):
                                            best_models[cache_key] = existing_data
                                        continue
                                except Exception:
                                    pass

                            try:
                                _, metrics = train_and_evaluate_kan(
                                    width=width,
                                    grid=grid,
                                    k=k,
                                    data_split=data_split,
                                    seed=seed,
                                    epochs=cfg.epochs,
                                    opt=cfg.opt,
                                    lr=cfg.lr,
                                    patience=cfg.patience,
                                    min_delta=cfg.min_delta,
                                    monitor=cfg.monitor,
                                    restore_best_weights=cfg.restore_best_weights,
                                    device_str=cfg.device,
                                    strict_determinism=cfg.strict_determinism,
                                )

                                save_json_result(str(res_file), metrics)
                                append_summary_csv(str(global_csv), metrics, COLUMNS)
                                append_summary_csv(str(model_csv), metrics, COLUMNS)

                                # Update best-model tracking by validation error
                                val_err = metrics["Val Error"]
                                if cache_key not in best_models or val_err < best_models[cache_key]["Val Error"]:
                                    best_models[cache_key] = metrics
                                    update_best_model_csv(str(best_csv), best_models, BEST_COLUMNS)

                                total_trained += 1
                                print(f"[M{model_type} S{scenario} Sd{seed}] {m_key:36s} | ValErr: {val_err:8.4f} | TestErr: {metrics['Test Error']:8.4f} | {metrics['Time Elapsed']:5.2f}s")

                            except Exception as e:
                                print(f"  [ERROR] Failed on {m_key} (M{model_type} S{scenario} Sd{seed}): {e}")
                            finally:
                                if torch.cuda.is_available():
                                    torch.cuda.empty_cache()
                                gc.collect()

    total_time = time.time() - start_total_time
    print("\n" + "=" * 75)
    print(f"KAN Simulation Suite Complete: Trained {total_trained} models, Skipped {total_skipped} existing.")
    print(f"Total Runtime: {total_time:.2f}s ({total_time / 3600:.2f} hours)")
    print(f"Summary CSV: {global_csv}")
    print(f"Best Models: {best_csv}")
    print("=" * 75)


if __name__ == "__main__":
    main()
