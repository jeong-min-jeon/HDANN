#!/usr/bin/env python3
"""
Full Real-World Benchmark Reproduction Script for KAN (California Housing 5-Fold CV).
PyTorch / pykan environment only.
No argparse: Loads settings from configs/kan_real_data.yaml or HYBRID_CONFIG.
"""

import gc
import json
import os
import sys
import time
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

import torch
from hybrid_network.config import KANRealDataConfig, load_config
from hybrid_network.data.housing import prepare_housing_split
from hybrid_network.kan.models import get_realdata_sweep_architectures, parse_custom_widths
from hybrid_network.kan.trainer import train_and_evaluate_kan
from hybrid_network.utils.io import append_summary_csv, save_json_result, update_best_model_csv

COLUMNS = [
    "Model", "Split", "Width", "Grid", "K", "Num Parameters", "Min Loss",
    "Val Error", "Test Error", "Time Elapsed", "Epochs Trained",
    "Inference Latency", "Peak GPU Memory (MB)", "Optimizer", "Device"
]

BEST_COLUMNS = [
    "Model", "Split", "Width", "Grid", "K", "Num Parameters", "Min Loss",
    "Val Error", "Test Error", "Time Elapsed", "Epochs Trained",
    "Peak GPU Memory (MB)", "Optimizer"
]


def main():
    cfg = load_config(KANRealDataConfig, "configs/kan_real_data.yaml")
    out_dir = Path(cfg.output_dir)
    if not out_dir.is_absolute():
        out_dir = PROJECT_ROOT / cfg.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    data_path = Path(cfg.data_path)
    if not data_path.is_absolute():
        data_path = PROJECT_ROOT / cfg.data_path

    global_csv = out_dir / "summary_realdata_kan_all.csv"
    best_csv = out_dir / "best_realdata_kan_results.csv"

    print("=" * 75)
    print("KAN Real Data Benchmark Runner (California Housing 5-Fold CV)")
    print(f"  Dataset Path:         {cfg.data_path}")
    print(f"  Output Directory:     {out_dir}")
    print(f"  Active Splits:        {cfg.splits}")
    print(f"  Spline Grids / Orders:{cfg.grids} / {cfg.ks}")
    print(f"  Optimizer / LR:       {cfg.opt} / {cfg.lr}")
    print(f"  Device:               {cfg.device}")
    print("=" * 75)

    data_cache = {}
    best_models = {}
    total_trained = 0
    total_skipped = 0
    start_total_time = time.time()

    if cfg.custom_widths:
        hidden_topos = parse_custom_widths(cfg.custom_widths)
        kan_widths = [[8] + h + [1] for h in hidden_topos]
    else:
        kan_widths = get_realdata_sweep_architectures(d=8)

    for split in cfg.splits:
        split_csv = out_dir / f"summary_realdata_kan_split_{split}.csv"
        split_seed = 2024 + ord(split.upper()) - ord("A")

        if split not in data_cache:
            data_cache[split] = prepare_housing_split(
                data_path=str(data_path),
                split=split,
                seed=2024
            )
        data_split = data_cache[split]

        for width in kan_widths:
            clean_w = [w[0] if isinstance(w, list) else int(w) for w in width]
            width_tag = "_".join(str(w) for w in clean_w)

            for grid in cfg.grids:
                for k in cfg.ks:
                    m_key = f"KAN_{width_tag}_G{grid}_K{k}_{cfg.opt}"
                    res_file = out_dir / f"{m_key}_split{split}.json"

                    if res_file.exists():
                        try:
                            with open(res_file, "r", encoding="utf-8") as f:
                                existing_data = json.load(f)
                            if existing_data.get("Status") == "SUCCESS":
                                total_skipped += 1
                                val_e = existing_data.get("Val Error", float("inf"))
                                if split not in best_models or val_e < best_models[split].get("Val Error", float("inf")):
                                    best_models[split] = existing_data
                                continue
                        except Exception:
                            pass

                    try:
                        _, metrics = train_and_evaluate_kan(
                            width=width,
                            grid=grid,
                            k=k,
                            data_split=data_split,
                            seed=split_seed,
                            epochs=cfg.epochs,
                            opt=cfg.opt,
                            lr=cfg.lr,
                            patience=cfg.patience,
                            min_delta=cfg.min_delta,
                            monitor=cfg.monitor,
                            restore_best_weights=cfg.restore_best_weights,
                            device_str=cfg.device,
                            strict_determinism=cfg.strict_determinism,
                        )

                        save_json_result(str(res_file), metrics)
                        append_summary_csv(str(global_csv), metrics, COLUMNS)
                        append_summary_csv(str(split_csv), metrics, COLUMNS)

                        val_err = metrics["Val Error"]
                        if split not in best_models or val_err < best_models[split]["Val Error"]:
                            best_models[split] = metrics
                            update_best_model_csv(str(best_csv), best_models, BEST_COLUMNS)

                        total_trained += 1
                        print(f"[Split {split}] {m_key:36s} | ValErr: {val_err:8.4f} | TestErr: {metrics['Test Error']:8.4f} | {metrics['Time Elapsed']:5.2f}s")

                    except Exception as e:
                        print(f"  [ERROR] Failed on {m_key} (Split {split}): {e}")
                    finally:
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                        gc.collect()

    total_time = time.time() - start_total_time
    print("\n" + "=" * 75)
    print(f"KAN Real Data Suite Complete: Trained {total_trained} models, Skipped {total_skipped} existing.")
    print(f"Total Runtime: {total_time:.2f}s ({total_time / 3600:.2f} hours)")
    print(f"Summary CSV: {global_csv}")
    print(f"Best Models: {best_csv}")
    print("=" * 75)


if __name__ == "__main__":
    main()
