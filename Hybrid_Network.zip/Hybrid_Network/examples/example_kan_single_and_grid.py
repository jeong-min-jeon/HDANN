#!/usr/bin/env python3
"""
Example: Single-Model Training and Mini Reproducible Grid Search for KAN.
PyTorch / pykan environment only.
No argparse: Run directly via `python examples/example_kan_single_and_grid.py`.
"""

import sys
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from hybrid_network.data.synthetic import prepare_synthetic_split
from hybrid_network.kan.trainer import train_and_evaluate_kan
from hybrid_network.utils.io import append_summary_csv


def run_single_kan_example():
    print("\n" + "=" * 70)
    print("Part 1: Single Model Training Example (KAN)")
    print("=" * 70)

    # 1. Prepare synthetic dataset for Model 1, Scenario 1, Seed 702
    data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)
    print(f"Dataset generated: Train={data_split.train_x.shape}, Val={data_split.val_x.shape}, Test={data_split.test_x.shape}")

    # 2. Train a single KAN model
    print("\nTraining single KAN model (width=[6, 4, 1], grid=3, k=2)...")
    model, metrics = train_and_evaluate_kan(
        width=[6, 4, 1],
        grid=3,
        k=2,
        data_split=data_split,
        seed=702,
        epochs=50,  # Fast demonstration epochs
        opt="Adam",
        lr=1e-4,
        patience=10,
        device_str="cpu",
    )

    print("\nTraining Complete! Returned Metrics Dictionary:")
    for k, v in metrics.items():
        print(f"  {k:22s}: {v}")

    # 3. Model prediction demonstration
    import torch
    with torch.no_grad():
        test_t = torch.tensor(data_split.test_x[:5], dtype=torch.float64, device=model.device)
        sample_preds = model(test_t).cpu().numpy()
    print(f"\nSample Predictions (first 5 test samples):\n{sample_preds.squeeze()}")


def run_mini_reproducible_kan_grid():
    print("\n" + "=" * 70)
    print("Part 2: Mini Reproducible Grid Search (KAN Width Sweep)")
    print("=" * 70)

    data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)
    csv_path = PROJECT_ROOT / "artifacts/metrics/examples/kan_mini_grid.csv"

    columns = [
        "Model", "Width", "Grid", "K", "Optimizer", "Seed",
        "Min Loss", "Val Error", "Test Error", "Time Elapsed",
        "Epochs Trained", "Num Parameters"
    ]

    configs = [
        ([6, 4, 1], 3, 2),
        ([6, 8, 1], 3, 2),
        ([6, 4, 4, 1], 3, 2),
        ([6, 8, 8, 1], 3, 2),
    ]

    print(f"Running 4-configuration mini-grid sequentially. Logging to: {csv_path}\n")

    for width, grid, k in configs:
        _, metrics = train_and_evaluate_kan(
            width=width,
            grid=grid,
            k=k,
            data_split=data_split,
            seed=702,
            epochs=50,
            opt="Adam",
            lr=1e-4,
            patience=10,
            device_str="cpu",
        )
        append_summary_csv(str(csv_path), metrics, columns)
        print(f"[{metrics['Model']}] -> Min Loss: {metrics['Min Loss']:.4f} | Val Error: {metrics['Val Error']:.4f} | Test Error: {metrics['Test Error']:.4f} | Params: {metrics['Num Parameters']}")

    print(f"\nMini KAN grid search complete! Results saved to {csv_path}")


if __name__ == "__main__":
    run_single_kan_example()
    run_mini_reproducible_kan_grid()
