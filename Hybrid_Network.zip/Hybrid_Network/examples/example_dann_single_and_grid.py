#!/usr/bin/env python3
"""
Example: Single-Model Training and Mini Reproducible Grid Search for DANN/HDANN.
TensorFlow / Keras environment only.
No argparse: Run directly via `python examples/example_dann_single_and_grid.py`.
"""

import sys
from pathlib import Path

# Add src to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from hybrid_network.data.synthetic import prepare_synthetic_split
from hybrid_network.dann.trainer import train_and_evaluate_dann
from hybrid_network.utils.io import append_summary_csv


def run_single_model_example():
    print("\n" + "=" * 70)
    print("Part 1: Single Model Training Example (DANN / HDANN)")
    print("=" * 70)

    # 1. Prepare synthetic dataset for Model 1, Scenario 1, Seed 702
    data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)
    print(f"Dataset generated: Train={data_split.train_x.shape}, Val={data_split.val_x.shape}, Test={data_split.test_x.shape}")

    # 2. Train a single HDANN_1 model
    print("\nTraining single HDANN_1 model (num_layer=3, unit_size=16, max_order=2, ReLU)...")
    model, metrics = train_and_evaluate_dann(
        arch_name="HDANN_1",
        num_layer=3,
        unit_size=16,
        max_order=2,
        activation="ReLU",
        base_type="FS",
        data_split=data_split,
        seed=702,
        epochs=100,  # Fast demonstration epochs
        lr=1e-4,
        patience=10,
        verbose=0
    )

    print("\nTraining Complete! Returned Metrics Dictionary:")
    for k, v in metrics.items():
        print(f"  {k:22s}: {v}")

    # 3. Model prediction demonstration
    sample_preds = model(data_split.test_x[:5]).numpy()
    print(f"\nSample Predictions (first 5 test samples):\n{sample_preds.squeeze()}")


def run_mini_reproducible_grid():
    print("\n" + "=" * 70)
    print("Part 2: Mini Reproducible Grid Search (DANN vs. HDANN_1)")
    print("=" * 70)

    data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)
    csv_path = PROJECT_ROOT / "artifacts/metrics/examples/dann_mini_grid.csv"

    columns = [
        "Model", "Architecture", "Num_Layer", "Unit_Size", "Max_Order",
        "Activation", "Seed", "Min Loss", "Val Error", "Test Error",
        "Time Elapsed", "Epochs Trained", "Num Parameters"
    ]

    configs = [
        ("DANN", 3, 4, 2, "sigmoid"),
        ("DANN", 3, 16, 2, "sigmoid"),
        ("HDANN_1", 3, 4, 2, "ReLU"),
        ("HDANN_1", 3, 16, 2, "ReLU"),
    ]

    print(f"Running 4-configuration mini-grid sequentially. Logging to: {csv_path}\n")

    for arch, layers, units, order, act in configs:
        _, metrics = train_and_evaluate_dann(
            arch_name=arch,
            num_layer=layers,
            unit_size=units,
            max_order=order,
            activation=act,
            base_type="FS",
            data_split=data_split,
            seed=702,
            epochs=100,
            lr=1e-4,
            patience=10,
            verbose=0
        )
        append_summary_csv(str(csv_path), metrics, columns)
        print(f"[{metrics['Model']}] -> Min Loss: {metrics['Min Loss']:.4f} | Val Error: {metrics['Val Error']:.4f} | Test Error: {metrics['Test Error']:.4f} | Params: {metrics['Num Parameters']}")

    print(f"\nMini grid search complete! Results saved to {csv_path}")


if __name__ == "__main__":
    run_single_model_example()
    run_mini_reproducible_grid()
