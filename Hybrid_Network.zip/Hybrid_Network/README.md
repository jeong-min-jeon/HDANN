# Hybrid_Network: DANN, HDANN, and KAN Research Benchmark Suite

This repository contains the official, publication-ready research benchmark suite comparing **Deep Additive Neural Networks (DANN)** and **Hierarchical DANN (HDANN)** against **Kolmogorov-Arnold Networks (KAN)** across both synthetic simulation scenarios (Models 1–4) and real-world data (California Housing 5-fold cross-validation).

---

## 1. Environment & Dependencies

To preserve modularity and prevent dependency conflicts between deep learning frameworks, this codebase maintains **strict framework isolation**:
- **DNN, DANN, and HDANN** require a **TensorFlow / Keras environment**:
  ```bash
  pip install -r requirements_dann.txt
  pip install -e .
  ```
- **KAN** requires a **PyTorch / `pykan` environment**:
  ```bash
  pip install -r requirements_kan.txt
  pip install -e .
  ```

Neither environment requires the other framework to be installed.

---

## 2. Quick Start: Single-Model Training & Evaluation

You can train any individual model and receive `(model, metrics_dict)` directly in Python without running a complex benchmark harness.

### Training a Single DANN / HDANN Model (TensorFlow Environment)
```python
from hybrid_network.data.synthetic import prepare_synthetic_split
from hybrid_network.dann.trainer import train_and_evaluate_dann

# 1. Prepare synthetic dataset (Model 1, Scenario 1, Seed 702)
data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)

# 2. Train and evaluate a single HDANN_1 model
model, metrics = train_and_evaluate_dann(
    arch_name="HDANN_1",
    num_layer=3,
    unit_size=16,
    max_order=2,
    activation="ReLU",
    base_type="FS",
    data_split=data_split,
    seed=702,
    epochs=1000,
    lr=1e-4,
    patience=10,
    verbose=0
)

# 3. Inspect unnormalized MSE metrics and test predictions
print("Validation Error:", metrics["Val Error"])
print("Test Error:      ", metrics["Test Error"])
predictions = model(data_split.test_x[:5]).numpy()
```

### Training a Single KAN Model (PyTorch Environment)
```python
import torch
from hybrid_network.data.synthetic import prepare_synthetic_split
from hybrid_network.kan.trainer import train_and_evaluate_kan

# 1. Prepare synthetic dataset (Model 1, Scenario 1, Seed 702)
data_split = prepare_synthetic_split(model_type=1, scenario=1, seed=702)

# 2. Train and evaluate a single KAN model
model, metrics = train_and_evaluate_kan(
    width=[6, 4, 1],
    grid=3,
    k=2,
    data_split=data_split,
    seed=702,
    epochs=1000,
    opt="Adam",
    lr=1e-4,
    patience=10,
    device_str="0"  # or "cpu"
)

# 3. Inspect unnormalized MSE metrics and test predictions
print("Validation Error:", metrics["Val Error"])
print("Test Error:      ", metrics["Test Error"])
with torch.no_grad():
    predictions = model(torch.tensor(data_split.test_x[:5], dtype=torch.float64)).cpu().numpy()
```

---

## 3. Fast Reproducible Examples

The `examples/` directory contains self-contained scripts designed to quickly demonstrate single-model training, metric outputs, and exact seed reproducibility on a compact 4-model grid search in under a minute.

### Run DANN Example (TensorFlow Environment)
```bash
python examples/example_dann_single_and_grid.py
```
*Outputs are saved to `artifacts/metrics/examples/dann_mini_grid.csv`.*

### Run KAN Example (PyTorch Environment)
```bash
python examples/example_kan_single_and_grid.py
```
*Outputs are saved to `artifacts/metrics/examples/kan_mini_grid.csv`.*

---

## 4. Full Paper Reproduction Experiments

All full-scale experiments are configuration-driven using declarative YAML files in `configs/` (**no `argparse` is used**). To override settings, simply edit the YAML file or point to a custom config via the `HYBRID_CONFIG` environment variable:
```bash
export HYBRID_CONFIG=configs/custom_experiment.yaml
```

### Full DANN Experiments (TensorFlow Environment)

1. **Synthetic Simulation Study (Models 1, 2, 3, and 4)**:
   ```bash
   python experiments/run_dann_simulation.py
   ```
   - Sweeps standard `DNN` baseline across `num_layer in [2, 4, 6, 8, 10, 12, 14, 16, 18]`, `unit_size in [8, 32, 128, 512, 2048]`, and `activations in ['ReLU', 'sigmoid', 'tanh']`.
   - Sweeps `DANN`, `HDANN_1`, `HDANN_2`, and `HDANN_3` across `num_layer in [1, 3, 5, 7, 9]` (`num_layer >= 3` for HDANN), `unit_size in [4, 16, 64, 256, 1024]`, `max_order in [2, 3, 4, 5]`, and `activations in ['ReLU', 'sigmoid', 'tanh']`.
   - Saves per-model JSONs and logs to `artifacts/metrics/dann_simulation/summary_simulation_all.csv`.

2. **Real-World Benchmark (California Housing 5-Fold Cross-Validation)**:
   ```bash
   python experiments/run_dann_real_data.py
   ```
   - Evaluates all DANN and HDANN architectures on Splits A, B, C, D, and E.
   - Logs to `artifacts/metrics/dann_real_data/summary_realdata_all.csv`.

---

### Full KAN Experiments (PyTorch Environment)

1. **Synthetic Simulation Study (Models 1, 2, 3, and 4)**:
   ```bash
   python experiments/run_kan_simulation.py
   ```
   - Evaluates the 50-architecture width & depth sweep (widths 4 to 1024, depths 1 to 10) with spline grids `G in [3, 5]` and spline orders `K in [2, 3]`.
   - Automatically tracks the best model per configuration in `artifacts/metrics/kan_simulation/best_kan_results.csv`.

2. **Real-World Benchmark (California Housing 5-Fold Cross-Validation)**:
   ```bash
   python experiments/run_kan_real_data.py
   ```
   - Evaluates the KAN architecture sweep across California Housing Splits A, B, C, D, and E.
   - Tracks the best models in `artifacts/metrics/kan_real_data/best_realdata_kan_results.csv`.

---

## 5. Repository Structure

```text
Hybrid_Network/
├── configs/                             # Declarative YAML configs (No argparse)
│   ├── dann_simulation.yaml
│   ├── dann_real_data.yaml
│   ├── kan_simulation.yaml
│   └── kan_real_data.yaml
├── data/
│   └── raw/
│       └── housing.csv                  # California Housing dataset
├── artifacts/                           # Output metrics, summary CSVs, checkpoints
├── src/
│   └── hybrid_network/
│       ├── config.py                    # Type-safe dataclass configs & YAML loader
│       ├── data/                        # Framework-agnostic synthetic & housing data
│       │   ├── synthetic.py             # Models 1-4, Scenarios 1 & 2
│       │   └── housing.py               # Deterministic 5-fold CV (seed=2024)
│       ├── dann/                        # TensorFlow/Keras: DANN & HDANN models & trainer
│       │   ├── models.py
│       │   └── trainer.py
│       ├── kan/                         # PyTorch/pykan: KAN models & trainer
│       │   ├── patches.py               # CUDA/CPU device sync patches
│       │   ├── models.py
│       │   └── trainer.py
│       └── utils/                       # Reproducibility seeds & atomic CSV/JSON IO
├── examples/                            # Fast single-model & mini-grid demonstrations
└── experiments/                         # Full paper reproduction experiment runners
```
